package com.anthony.zoo;

import java.time.LocalDate;
import java.util.ArrayList;


public class App {
    public static void main (String[] args){
        System.out.println("\n Welcome to my Zoo!");
        Animal  myNewAnimal = new Animal();
        System.out.println("\n Animal arrival date is " + myNewAnimal.getAniArrivalDate());

        LocalDate arrivalDate = LocalDate.now();
        LocalDate birthDate = LocalDate.now();


        // Use the Full Animal constructor
        // public Animal(String aniSex, LocalDate aniBirthDate, int aniWeight, String aniName,
        // String aniID, String aniColor, String aniOrigin, LocalDate aniArrivalDate)
        Animal anotherAnimal = new Animal("female", birthDate, 88, "Some Name", "LI06", "Brown and tan", "from Zanzibar, Tanzania", arrivalDate);

        //Output anotherAnimal
        System.out.println("\nSex is: " + anotherAnimal.getAniSex());
        System.out.println("\nBirthdate is: " + anotherAnimal.getAniBirthDate());
        System.out.println("\nWeight is: " + anotherAnimal.getAniWeight());
        System.out.println("\nName is: " + anotherAnimal.getAniName());
        System.out.println("\nID is: " + anotherAnimal.getAniID());
        System.out.println("\nColor is: " + anotherAnimal.getAniColor());
        System.out.println("\nOrigin is: " + anotherAnimal.getAniOrigin());
        System.out.println("\nArrival date is is: " + anotherAnimal.getAniArrivalDate());

        // Create a new lion
        Lion myNewLion = new Lion();
        // output the arrival date of the new lion
        System.out.println("\n My new lion arrived: " + myNewLion.getAniArrivalDate());
        // how many lions were created? (1)
        System.out.println("\n The amount of lions created: " + Lion.getNumOfLions());
        // how many animals do we have? (Should have 3 animals)
        System.out.println("\n The amount of animals created: " + Lion.getNumOfAnimals());


        // Create a new Hyena
        Hyena myNewHyena = new Hyena("This");
        Hyena anotherHyena = new Hyena("That");
        // Create an arraylist of objects
        ArrayList<Hyena> myHyenas = new ArrayList<>();
        // add a hyena to array list
        myHyenas.add(myNewHyena);
        // Add another
        myHyenas.add(anotherHyena);
        // use a for loop
        String aUsefulName = "";
        for (int i = 0; i<4; i++){
            aUsefulName = aUsefulName + i;
            Hyena hyena = new Hyena(aUsefulName);
            // add a hyena to array list
            myHyenas.add(hyena);
        }

        // use a for:each loop to output the ArrayList of hyenas
        for (Hyena aHyena : myHyenas){
            System.out.println("\n aHyena is " + aHyena);
            System.out.println("\n aHyena's name is " + aHyena.getAniName());
        }

        System.out.println("\n Numer of hyenas is " + Hyena.getNumOfHyenas());
        System.out.println("\n Numer of lions is " + Lion.getNumOfLions());
        System.out.println("\n Numer of animals is " + Animal.getNumOfAnimals());





    }
}
