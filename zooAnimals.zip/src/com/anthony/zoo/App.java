// aJ
// 9/30/25
// continued on 10/2/25 - 10/7/25
// App.java
// ZOO PRACTICE TIME!

package com.anthony.zoo;


public class App {
    public static void main(String[] args) {

        System.out.println("Welcome to my Zoo Keeper Challenge!!");
        // How many animals do we have?
        System.out.println("\n numOfAnimals is " + Animal.numOfAnimals);
        // create a new animal
        Animal myNewAnimal = new Animal("a",1,"b");
        // test
        System.out.println("\n myNewAnimal objects ID is: " + myNewAnimal.getAniID());
        // Give our new animal an ID
        myNewAnimal.setAniID("acd123");
        System.out.println("\n The setAnimalID() method was called !");
        System.out.println("\n myNewAnimal objects ID is: " + myNewAnimal.getAniID());
        // How many animals do we have?
        System.out.println("\n numOfAnimals is " + Animal.numOfAnimals);
        // create another animal
        Animal anotherAnimal = new Animal("a",1,"b");
        // How many animals do we have?
        System.out.println("\n numOfAnimals is " + Animal.numOfAnimals);
        Animal myDemoAnimal = new Animal("Leo", 8000, "LI09");
        System.out.println("My demo animals name is " + myDemoAnimal.getName());





    }
}