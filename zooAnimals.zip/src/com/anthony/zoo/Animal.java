// aJ
// 9/30/25
// continued on 10/2/25 - 10/7/25
// Animal.java

package com.anthony.zoo;


public class Animal {
    // Private attributes
    private String aniID;
    private String aniBirthdate;
    private String aniColor;
    private int aniWeight;
    private String aniOrigin;
    private String aniArrivalDate;
    private String aniName;
    private String aniSound;
    private String aniSex;
    static int numOfAnimals = 0;

// THIS IS THE "CALL TO THE CONSTRUCTOR"
    public Animal(String myName, int theWeight, String someID) {
        this.aniName = myName;
        this.aniWeight = theWeight;
        this.aniID = someID;
        numOfAnimals++;
    }


    // Public getters and setters
    public String getAniID() {
        return aniID;
    }
    public void setAniID(String aniID) {
        this.aniID = aniID;
    }
    public String getBirthdate() {
        return aniBirthdate;
    }
    public void setBirthdate(String birthdate) {
        this.aniBirthdate = birthdate;
    }
    public String getColor() {
        return aniColor;
    }
    public void setColor(String color) {
        this.aniColor = color;
    }
    public int getWeight() {
        return aniWeight;
    }
    public void setWeight(int weight) {
        this.aniWeight = weight;
    }
    public String getOrigin() {
        return aniOrigin;
    }
    public void setOrigin(String origin) {
        this.aniOrigin = origin;
    }
    public String getArrivalDate() {
        return aniArrivalDate;
    }
    public void setArrivalDate(String arrivalDate) {
        this.aniArrivalDate = arrivalDate;
    }
    public String getName() {
        return aniName;
    }

    public void setName(String name) {
        this.aniName = name;
    }

    public String getAniSound() {
        return aniSound;
    }

    public void setAniSound(String aniSound) {
        this.aniSound = aniSound;
    }

    public String getSex() {
        return aniSex;
    }

    public void setSex(String sex) {
        this.aniSex = sex;
    }

    public static int getNumOfAnimals() {
        return numOfAnimals;
    }

    public static void setNumOfAnimals(int numOfAnimals) {
        Animal.numOfAnimals = numOfAnimals;
    }

    public static void decrementAnimalCount() {
        if (numOfAnimals > 0) {
            numOfAnimals--;


        }
    }
}